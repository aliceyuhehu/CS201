# CS201-APTs
Solutions for Algorithmic Problem-solving Testing (APTs) @ Duke CS

APTs are problems very similar to ones found in LeetCode and other platforms online. Most famous ones have even been replicated by those websites and credited to the amazing professors at Duke who developed them.

One important point to notice with APTs is that efficiency is not taken into consideration: the main goal is to solve the problem. Some of the APTs at this repo have also been taken in a time-constrained environment for grading.

You can find the prompt for most problems by googling the Java class name + "Duke APT".
